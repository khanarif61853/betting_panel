// const BASE_URL = "https://blacksattaapi.indutechit.com"
const BASE_URL = "http://192.168.1.15:3002"

export {BASE_URL}