import React from 'react'
import Routing from './routes/Routing'

const App = () => {
  return (
    <Routing/>
  )
}

export default App
